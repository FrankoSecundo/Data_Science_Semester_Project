% -------------------------------------------------------------------------
%
% Run different simplifications of a mass-based
% Anaerobic Digestion Model No. 1 (ADM1)
%
% Example: Anaerobic co-digestion of maize silage and cattle manure
%
% Implementation in Matlab 
% R2019b (The MathWorks, Inc.)
%
% Matlab ODE function
%
% Version 1.0
%
% https://github.com/soerenweinrich/ADM1
%
% Copyright (c) 2021 Sören Weinrich
% E-Mail: soeren.weinrich@dbfz.de
%
% Additional information (citation example):
%
% Weinrich, S.; Nelles, M. (2021).
% Systematic simplification of the Anaerobic Digestion Model No. 1 (ADM1) -
% Model development and stoichiometric analysis. Bioresource Technology. 
% In press. https://doi.org/10.1016/j.biortech.2021.125124.
%
% -------------------------------------------------------------------------

clear all
clc

%% Initialise model
% Load standard model parameters
load('Model_data\ADM1_parameters.mat')
% Load experimental data
load('Model_data\ADM1_input_data.mat')
% Select model type: ADM1, ADM1_R1, ADM1_R2, ADM1_R3 or ADM1_R4
model = 'ADM1_R4';
% Set time range in days
time_range = [0 100];
%% set up the for loop
csvfiles = dir('structures\feed_inputs\Individual_inputs\*.csv')

for file = csvfiles'

    IIinput = readtable(file.name,'PreserveVariableNames',true)
    
%% Run selected model 
switch model
    case 'ADM1_R4'
        % Solve ODE of mass-based ADM1-R4
        ode = ode15s(@(t,x) ADM1_R4_mass(t,x,system.Variables,IIinput.Variables,parameters.ADM1_R4.Variables),time_range,initial.ADM1_R4.Variables);
        % Calculate model ouput
        num_t = size(ode.x,2);
        for i = 1:num_t
            [t(i),y(i,:)] = ADM1_R4_mass_output(ode.x(1,i),ode.y(:,i),system.Variables,parameters.ADM1_R4.Variables);
        end
    otherwise
        % Stop script if specific model name does not match available model structures
        warning(['Model name incorrect. The selected model name "',model,'" does not match available model structures.'])
        return
end

%% Set model output
output1=output.ADM1_R4;
output1{1:num_t,:} = [t' y];

curfile = strcat("Output\","O_",file.name)

    writetable(output1, curfile)

end

%% Clear variables 
clearvars i num_t t y l time_range



%% Clear variables 
clearvars i num_t t y l time_range